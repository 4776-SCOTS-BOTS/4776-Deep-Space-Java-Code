package org.usfirst.frc.team4776.robot.Pixy;

public class PixyException extends Exception {
	public PixyException(String message)
	{
		super(message);
	}
}
