
package org.usfirst.frc.team4776.robot;

import edu.wpi.first.wpilibj.I2C;
import edu.wpi.first.wpilibj.I2C.Port;
import edu.wpi.first.wpilibj.IterativeRobot;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;
import edu.wpi.first.wpilibj.command.Scheduler;
import edu.wpi.first.wpilibj.livewindow.LiveWindow;

import org.usfirst.frc.team4776.robot.Pixy.*;
import org.usfirst.frc.team4776.robot.commands.*;
import org.usfirst.frc.team4776.robot.subsystems.*;
import edu.wpi.first.wpilibj.smartdashboard.SendableChooser;
import edu.wpi.first.wpilibj.smartdashboard.SmartDashboard;

/**
 * The VM is configured to automatically run this class, and to call the
 * functions corresponding to each mode, as described in the IterativeRobot
 * documentation. If you change the name of this class or the package after
 * creating this project, you must also update the manifest file in the resource
 * directory.
 */
enum DriveSystem
 {
		TankDrive, //Manually control each side
		ArcadeDrive, //Forward input and turn input
		CheesyDrive, //Curvature Drive - Like a car
		TestDrive, //Test Robot - Currently is used for Pixy2 Testing
		CalDrive, //Calibrate robot
		HoloDrive; //Wheels on the corner drivetrain
}
public class Robot extends IterativeRobot {
	public static final DriveSystem driveStyle = DriveSystem.CalDrive;
	public static final ExampleSubsystem exampleSubsystem = new ExampleSubsystem();
	public static final DriveTrainSubsystem driveTrainSubsystem = new DriveTrainSubsystem();
	public static final HolonomicDriveSubsystem holoDriveSubsystem = new HolonomicDriveSubsystem();
	public static OI oi;
	private Joystick m_stick = new Joystick(0);
	private Joystick n_stick = new Joystick(1);
	private Timer m_timer = new Timer();
	
	//Pixy: is this Pixy1 or 2?
	PixyPacket[] packet1 = new PixyPacket[7];
	String print;
	PixyI2C pixy = new PixyI2C("Pixy", new I2C(Port.kOnboard, 0x54), packet1, new PixyException(print), new PixyPacket());
	
    Command autonomousCommand;
    SendableChooser chooser;

    /**
     * This function is run when the robot is first started up and should be
     * used for any initialization code.
     */
    public void robotInit() {
    	RobotMap.GYRO.calibrate();
    	RobotMap.GYRO.reset();
    	System.out.println("ROBO INIT ANGLE: " + driveTrainSubsystem.getAngle());
		oi = new OI();
        chooser = new SendableChooser();
        chooser.addDefault("Default Auto", new GyroTurn(-90, true, 0.65));
//        chooser.addObject("My Auto", new MyAutoCommand());
        SmartDashboard.putData("Auto mode", chooser);
    }
	
	/**
     * This function is called once each time the robot enters Disabled mode.
     * You can use it to reset any subsystem information you want to clear when
	 * the robot is disabled.
     */
    public void disabledInit(){

    }
	
	public void disabledPeriodic() {
		Scheduler.getInstance().run();
	}

	/**
	 * This autonomous (along with the chooser code above) shows how to select between different autonomous modes
	 * using the dashboard. The sendable chooser code works with the Java SmartDashboard. If you prefer the LabVIEW
	 * Dashboard, remove all of the chooser code and uncomment the getString code to get the auto name from the text box
	 * below the Gyro
	 *
	 * You can add additional auto modes by adding additional commands to the chooser code above (like the commented example)
	 * or additional comparisons to the switch structure below with additional strings & commands.
	 */
    public void autonomousInit() {
    	RobotMap.GYRO.reset();
        autonomousCommand = (Command) chooser.getSelected();
        
		/* String autoSelected = SmartDashboard.getString("Auto Selector", "Default");
		switch(autoSelected) {
		case "My Auto":
			autonomousCommand = new MyAutoCommand();
			break;
		case "Default Auto":
		default:
			autonomousCommand = new ExampleCommand();
			break;
		} */
    	
    	// schedule the autonomous command (example)
        if (autonomousCommand != null) autonomousCommand.start();
    }

    /**
     * This function is called periodically during autonomous
     */
    public void autonomousPeriodic() {
        Scheduler.getInstance().run();
    }

    public void teleopInit() {
        m_timer.reset();
        m_timer.start();
        driveTrainSubsystem.resetGyro();
        driveTrainSubsystem.resetEncoders();
		// This makes sure that the autonomous stops running when
        // teleop starts running. If you want the autonomous to 
        // continue until interrupted by another command, remove
        // this line or comment it out.
        if (autonomousCommand != null) autonomousCommand.cancel();
		if (driveStyle == DriveSystem.TestDrive)
		{
	        System.out.println("TEST_TELEOP_INIT: STARTING");
	    	try {
				packet1[0] = pixy.readPacket(1);
			} catch (PixyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	System.out.println("X: " + packet1[0].X + "Y: " + packet1[0].Y + "W: " + packet1[0].Width + "H: " + packet1[0].Height);
		}
        
    }

    /**
     * This function is called periodically during operator control
     */
    public void teleopPeriodic() {
        Scheduler.getInstance().run();
        //System.out.println("LEFT RAW: " + driveTrainSubsystem.getLeftEncoderRaw());
        //System.out.println("RIGHT RAW: " + driveTrainSubsystem.getRightEncoderRaw());
        //System.out.println("LEFT REAL: " + driveTrainSubsystem.getLeftEncoder());
        //System.out.println("RIGHT REAL: " + driveTrainSubsystem.getRightEncoder());
        //System.out.println("AVG AVG: " + driveTrainSubsystem.getAverageEncoderPosition());
        //TODO Fix Tank/Arcade/Cheesy Drives
        if (driveStyle == DriveSystem.TankDrive)
		{
			//m_robotDrive.tankDrive(m_stick.getRawAxis(1), m_stick.getRawAxis(5));
		}
		else if (driveStyle == DriveSystem.ArcadeDrive)
		{
			//m_robotDrive.arcadeDrive(m_stick.getRawAxis(1), m_stick.getRawAxis(4));
		}
		else if (driveStyle == DriveSystem.CheesyDrive)
		{
			//m_robotDrive.curvatureDrive(m_stick.getRawAxis(1), m_stick.getRawAxis(4), m_stick.getRawButton(1));
		}
		else if (driveStyle == DriveSystem.TestDrive)
		{

		}
		else if (driveStyle == DriveSystem.CalDrive)
		{
			double rightX = m_stick.getRawAxis(4);
			double leftY = -m_stick.getRawAxis(1);
			driveTrainSubsystem.cheesyDrive(leftY, rightX, m_stick.getRawButton(6));
			if (n_stick.getRawButton(1))
			{
				//time,leftD,rightD,angle,rightX,leftY
				//System.out.println(m_timer.get() + " " + driveTrainSubsystem.getLeftEncoder() + " " + driveTrainSubsystem.getRightEncoder() + " " + driveTrainSubsystem.getAngle() + " " + rightX + " " + leftY);
			}
			System.out.println(driveTrainSubsystem.getLeftEncoderRaw() + " " + driveTrainSubsystem.getRightEncoderRaw());
		}
		else if (driveStyle == DriveSystem.HoloDrive)
		{
			//get joystick inputs
			double gamepad1LeftY = m_stick.getRawAxis(1);
			double gamepad1LeftX = -m_stick.getRawAxis(0) * 0;
			double gamepad1RightX = -m_stick.getRawAxis(4);
			// holonomic formulas
			double FrontLeft = -gamepad1LeftY - gamepad1LeftX - gamepad1RightX;
			double FrontRight = gamepad1LeftY - gamepad1LeftX - gamepad1RightX;
			double BackRight = gamepad1LeftY + gamepad1LeftX - gamepad1RightX;
			double BackLeft = -gamepad1LeftY + gamepad1LeftX - gamepad1RightX;
			// clip the right/left values so that the values never exceed +/- 1
			FrontRight = clip(FrontRight, -0.7, 0.7);
			FrontLeft = clip(FrontLeft, -0.7, 0.7);
			BackLeft = clip(BackLeft, -0.7, 0.7);
			BackRight = clip(BackRight, -0.7, 0.7);
			// write the values to the motors
			holoDriveSubsystem.setSpeed(FrontLeft, BackLeft, BackRight, FrontRight);
		}
    }
    
    /**
     * This function is called periodically during test mode
     */
    public void testPeriodic() {
        LiveWindow.run();
    }
    
    private double clip (double value, double min, double max)
    {
    	return (Math.min(max, Math.max(min, value)));
    }
}
