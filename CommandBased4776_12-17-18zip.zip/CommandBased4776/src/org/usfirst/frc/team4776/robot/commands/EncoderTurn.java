package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 *
 */
public class EncoderTurn extends Command {

	private int centerPivotRadius = 12;
	private int sidePivotRadius = 24;
	private double leftSpeed;
	private double rightSpeed;
	private double distance;
	private boolean edgeTurn;
	
	//For sign on angle: clockwise is positive, cc is negative.
    public EncoderTurn(double speed, double angle, boolean _edgeTurn) {
    	requires(Robot.driveTrainSubsystem);
    	if (_edgeTurn){
    		distance = Math.abs(angle) * 3.14 * sidePivotRadius / 180;
    		if (angle >= 0)
    		{
            	leftSpeed = speed;
            	rightSpeed = 0;
    		}
    		else
    		{
            	leftSpeed = 0;
            	rightSpeed = speed;
    		}
    	} else
    	{
    		distance = Math.abs(angle) * 3.14 * centerPivotRadius / 180;
    		if (angle >= 0)
    		{
            	leftSpeed = speed;
            	rightSpeed = -speed;
    		}
    		else
    		{
            	leftSpeed = -speed;
            	rightSpeed = speed;
    		}
    	}
    	setTimeout(30);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	System.out.println("STARTING, GOAL= " + distance);
    	Robot.driveTrainSubsystem.setSpeed(leftSpeed, rightSpeed);
    	Robot.driveTrainSubsystem.resetEncoders();
    	//added 11/18 setDistance
    	Robot.driveTrainSubsystem.setDistance();
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	Robot.driveTrainSubsystem.setSpeed(leftSpeed, rightSpeed);
    	System.out.println(Robot.driveTrainSubsystem.getAverageAbsEncoderPosition());
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
    	return (!(Robot.driveTrainSubsystem.getAverageAbsEncoderPosition() < distance) ||  isTimedOut());
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.driveTrainSubsystem.setSpeed(0.0, 0.0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	end();
    }
}
