package org.usfirst.frc.team4776.robot.subsystems;

import org.usfirst.frc.team4776.robot.RobotMap;

import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.command.Subsystem;

/**
 *
 */
public class HolonomicDriveSubsystem extends Subsystem {

	Victor hFrontLeft = RobotMap.H_FRONT_LEFT;
	Victor hRearLeft = RobotMap.H_REAR_LEFT;
	Victor hRearRight = RobotMap.H_REAR_RIGHT;
	Victor hFrontRight = RobotMap.H_FRONT_RIGHT;

    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }
    
    public void setSpeed (double frontLeft, double rearLeft, double rearRight, double frontRight)
    {
    	hFrontLeft.set(frontLeft);
        hRearLeft.set(rearLeft);
        hRearRight.set(rearRight);
        hFrontRight.set(frontRight);
    }
}

