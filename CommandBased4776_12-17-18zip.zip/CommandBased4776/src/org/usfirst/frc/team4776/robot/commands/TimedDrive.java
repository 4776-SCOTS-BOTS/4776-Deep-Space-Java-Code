package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 *
 */
public class TimedDrive extends Command {

	private double leftSpeed;
	private double rightSpeed;
	
    public TimedDrive (double _leftSpeed, double _rightSpeed, float timeOutTime) {
        // Use requires() here to declare subsystem dependencies
        requires(Robot.driveTrainSubsystem);
        leftSpeed = _leftSpeed;
        rightSpeed = _rightSpeed;
        setTimeout(timeOutTime);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	Robot.driveTrainSubsystem.setSpeed(leftSpeed, rightSpeed);
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	Robot.driveTrainSubsystem.setSpeed(leftSpeed, rightSpeed);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return isTimedOut();
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.driveTrainSubsystem.setSpeed(0.0, 0.0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	end();
    }
}
