package main.java.frc.team4150.robot.input;

/**
 * Represents some form of human input. Completely useless as of now, might add some important methods if needed later
 * @author cat16
 */
public abstract class InputBase {

}
