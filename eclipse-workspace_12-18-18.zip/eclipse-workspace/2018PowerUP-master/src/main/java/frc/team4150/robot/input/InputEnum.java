package main.java.frc.team4150.robot.input;

/**
 * Represents enums for input types
 * @author cat16
 */
public interface InputEnum {
    InputBase getInput();
}
