package org.usfirst.frc.team4776.robot;

public class PixyException extends Exception {
public PixyException(String message){
super(message);
}
}