package org.usfirst.frc.team4776.robot;

public class PixyPacket {
public int X;
public int Y;
public int Width;
public int Height;
}