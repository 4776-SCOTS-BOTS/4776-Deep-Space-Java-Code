package com.team254.frc2018.loops;

public interface ILooper {
    void register(Loop loop);
}
