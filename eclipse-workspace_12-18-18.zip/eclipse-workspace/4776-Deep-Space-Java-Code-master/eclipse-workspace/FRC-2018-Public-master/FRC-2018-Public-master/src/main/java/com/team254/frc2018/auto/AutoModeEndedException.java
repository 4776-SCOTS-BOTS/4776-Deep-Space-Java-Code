package com.team254.frc2018.auto;

/**
 * Exception thrown when an auto mode ends unexpectedly
 */
public class AutoModeEndedException extends Exception {
    private static final long serialVersionUID = 1411131586291540143L;
}