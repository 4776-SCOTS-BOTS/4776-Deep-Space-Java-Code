package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 * Turn using the gyro to keep you straight using PID!
 */
public class PIDGyroDrive extends Command {

	//Gain = 16.0
	//OssolationPeriod(OP) = 0.53
	double P = 7.2; //P = 0.45 * Gain
	double I = 16.3; //I = 0.54 * Gain / OP
	double targetAngle;
	double integral;
	double previousError;
	double PIDOutput;
	
    public PIDGyroDrive(double _targetAngle, double _baseSpeed) {
    	requires(Robot.driveTrainSubsystem);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return false;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
