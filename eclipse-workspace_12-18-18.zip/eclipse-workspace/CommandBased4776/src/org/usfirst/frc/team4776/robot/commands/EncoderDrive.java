package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.command.Command;

/**
 *
 */
public class EncoderDrive extends Command {

	private float distance;
	private double speed;
	
    public EncoderDrive(double _speed, float _distance) {
        // Use requires() here to declare subsystem dependencies
        requires(Robot.driveTrainSubsystem);
        speed = _speed;
        distance = _distance;
        setTimeout(15);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	Robot.driveTrainSubsystem.setSpeed(speed, speed);
    	Robot.driveTrainSubsystem.resetEncoders();
    	//added 11/18 setDistance
    	Robot.driveTrainSubsystem.setDistance();
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	//added 11/18
    	Robot.driveTrainSubsystem.setSpeed(speed, speed);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        
    	return (!(Robot.driveTrainSubsystem.getAverageEncoderPosition() < distance) ||  isTimedOut());
        
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.driveTrainSubsystem.setSpeed(0.0, 0.0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	end();
    }
}
