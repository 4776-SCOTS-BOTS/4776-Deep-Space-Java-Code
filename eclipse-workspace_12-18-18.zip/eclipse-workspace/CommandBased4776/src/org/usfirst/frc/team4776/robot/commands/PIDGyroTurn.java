package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;

/**
 * Turn using the gyro using PID!
 */
public class PIDGyroTurn extends Command {

	double Gain = 0.10; //Good at 12, perfect at 16
	double OssolationPeriod = 0.53;
	double P = .45 * Gain; //P = 0.45 * Gain
	double I = 0 * .54 * Gain / OssolationPeriod; //I = 0.54 * Gain / OP
	double targetAngle;
	double integral;
	double previousError;
	double previousTime;
	double PIDOutput;
	Timer r_timer = new Timer();
	
	void PID()
	{
		double dTime = r_timer.get() - previousTime; //calculate delta-time (change in time from previous loop)
		double error = targetAngle - Robot.driveTrainSubsystem.getAngle(); //error = target - actual
		integral += error * dTime; //add to the total integral
		PIDOutput = (P * error + I * integral); //Sum the P and I terms to get the output
		previousTime = r_timer.get();
	}
	
    public PIDGyroTurn(double _targetAngle) {
    	requires(Robot.driveTrainSubsystem);
    	targetAngle = _targetAngle;
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	PID();
    	System.out.println("AN: " + Robot.driveTrainSubsystem.getAngle() + " PO: " + PIDOutput);
    	PIDOutput = Math.max(0.50, Math.min(0.99, Math.abs(PIDOutput))) * Math.signum(PIDOutput);
    	Robot.driveTrainSubsystem.setSpeed(PIDOutput, -PIDOutput);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return false;
    }

    // Called once after isFinished returns true
    protected void end() {
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    }
}
