package org.usfirst.frc.team4776.robot.commands;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;

/**
 * Turn using the gyro and ramp into it!
 */
public class RampGyroTurn extends Command {

	private double targetAngle;
	private double speed;
	private double angleThreshold;
	private Timer r_timer = new Timer();
	
	//TODO change timeout back to 15 second timeout
    public RampGyroTurn(double _angle, double _speed) {
    	requires(Robot.driveTrainSubsystem);
    	targetAngle = _angle;
    	speed = _speed;
    	angleThreshold = 5;
    	setTimeout(150);
    }
    public RampGyroTurn(double _angle, double _speed, double _angleThreshold) {
    	requires(Robot.driveTrainSubsystem);
    	targetAngle = _angle;
    	speed = _speed;
    	angleThreshold = _angleThreshold;
    	setTimeout(150);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	r_timer.reset();
    	r_timer.start();
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	double angle = Robot.driveTrainSubsystem.getAngle();
    	double scale = (angle - targetAngle) / 180;
    	double power = Math.min(0.99, speed * scale);
    	Robot.driveTrainSubsystem.setSpeed(-power, power);
    	System.out.println(r_timer.get() + " " + angle);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return (isTimedOut() || (false && (Math.abs(targetAngle - Robot.driveTrainSubsystem.getAngle()) < angleThreshold)));
    }

    // Called once after isFinished returns true
    protected void end() {
    	//System.out.println("JUST FINISHED TURNING in RampGyroTurn.");
		Robot.driveTrainSubsystem.setSpeed(0, 0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	end();
    }
}
