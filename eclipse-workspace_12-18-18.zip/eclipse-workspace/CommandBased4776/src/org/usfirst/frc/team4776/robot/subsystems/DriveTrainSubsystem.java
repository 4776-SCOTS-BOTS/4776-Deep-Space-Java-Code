package org.usfirst.frc.team4776.robot.subsystems;

import org.usfirst.frc.team4776.robot.RobotMap;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

/**
 *
 */
public class DriveTrainSubsystem extends Subsystem {

	DifferentialDrive driveTrain = RobotMap.DRIVE_TRAIN;
	Encoder leftEncoder = RobotMap.LEFT_ENCODER;
	Encoder rightEncoder = RobotMap.RIGHT_ENCODER;
    ADXRS450_Gyro gyro = RobotMap.GYRO;
	
	//added 11/18 encoder drive updates
	// Constants
	private static final double kDistancePerRevolutionLeft = 1.52;  //This is circumference. C = pi * diameter (in feet)
	private static final double kDistancePerRevolutionRight = 1.54;  //This is circumference. C = pi * diameter (in feet)
	private static final double kPulsesPerRevolutionLeft = 1256;     // update - old-1233
	private static final double kPulsesPerRevolutionRight = 1426;     // update - supposed to be 127
	private static final double kDistancePerPulseLeft = kDistancePerRevolutionLeft / kPulsesPerRevolutionLeft;
	private static final double kDistancePerPulseRight = kDistancePerRevolutionRight / kPulsesPerRevolutionRight;
	//OLD
	//private static final double kDistancePerRevolution = 18.84;  //update
	//private static final double kPulsesPerRevolution = 1024;     // update
	//private static final double kDistancePerPulse = kPulsesPerRevolution / kDistancePerRevolution;
	
	public DriveTrainSubsystem() {
		
	}
		
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }
    
    public void setSpeed (double left, double right)
    {
    	driveTrain.tankDrive(left, right);
    }
    public void cheesyDrive (double speed, double turn, boolean isQuickTurn)
    {
    	driveTrain.curvatureDrive(speed, turn, isQuickTurn);
    }
    public void resetEncoders ()
    {
    	leftEncoder.reset();
    	rightEncoder.reset();
    }
    //added 11/18
    public double getAverageEncoderPosition() {
        return (((double)leftEncoder.getRaw() / kDistancePerPulseLeft) + ((double)rightEncoder.getRaw() / kDistancePerPulseRight)) / 2;
    }
    public double getAverageAbsEncoderPosition() {
        return (((double)Math.abs(leftEncoder.getRaw()) / kDistancePerPulseLeft) + ((double)Math.abs(rightEncoder.getRaw()) / kDistancePerPulseRight)) / 2;
    }
    public double getLeftEncoder()
    {
    	return leftEncoder.getRaw() * kDistancePerPulseLeft;
    }
    public double getRightEncoder()
    {
    	return rightEncoder.getRaw() * kDistancePerPulseRight;
    }
    public double getLeftEncoderRaw()
    {
    	return leftEncoder.getRaw();
    }
    public double getRightEncoderRaw()
    {
    	return rightEncoder.getRaw();
    }
    
    public double getAngle ()
    {
    	return gyro.getAngle();
    }
    public void resetGyro ()
    {
    	gyro.reset();
    }
    public void calibrateGyro ()
    {
    	gyro.calibrate();
    }
    
  //added 11/18
	public void setDistance() {
		leftEncoder.setDistancePerPulse(kDistancePerPulseLeft);
	    rightEncoder.setDistancePerPulse(kDistancePerPulseRight);
	}
	
	
}

