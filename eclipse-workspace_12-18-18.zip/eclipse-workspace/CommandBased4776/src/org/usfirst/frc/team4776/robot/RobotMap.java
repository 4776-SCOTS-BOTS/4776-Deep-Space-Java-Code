package org.usfirst.frc.team4776.robot;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Encoder;
import edu.wpi.first.wpilibj.SPI;
import edu.wpi.first.wpilibj.Victor;
import edu.wpi.first.wpilibj.ADXRS450_Gyro;
/**
 * The RobotMap is a mapping from the ports sensors and actuators are wired into
 * to a variable name. This provides flexibility changing wiring, makes checking
 * the wiring easier and significantly reduces the number of magic numbers
 * floating around.
 */
public class RobotMap {
    // For example to map the left and right motors, you could define the
    // following variables to use with your drivetrain subsystem.
    public static DifferentialDrive DRIVE_TRAIN = 
    		new DifferentialDrive(new Victor(11), new Victor(13));
    public static Encoder LEFT_ENCODER = new Encoder(9, 8, true, Encoder.EncodingType.k4X);
    public static Encoder RIGHT_ENCODER = new Encoder(0, 1, false, Encoder.EncodingType.k4X);
    //For gyro below: Make sure correct CS_ is used! NORMALLY CS0
    public static ADXRS450_Gyro GYRO = new ADXRS450_Gyro(SPI.Port.kOnboardCS0);
    public static Victor H_FRONT_LEFT = new Victor(0);
    public static Victor H_REAR_LEFT = new Victor(1);
    public static Victor H_REAR_RIGHT = new Victor(2);
    public static Victor H_FRONT_RIGHT = new Victor(3);
    
    // If you are using multiple modules, make sure to define both the port
    // number and the module. For example you with a rangefinder:
    // public static int rangefinderPort = 1;
    // public static int rangefinderModule = 1;
}
