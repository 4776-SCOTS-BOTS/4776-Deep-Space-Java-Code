package org.usfirst.frc.team4776.robot.commands;

import java.awt.geom.Point2D;

import org.usfirst.frc.team4776.robot.Robot;

import edu.wpi.first.wpilibj.Timer;
import edu.wpi.first.wpilibj.command.Command;

/**
 *	Encoder drive but ramps up speed. Modified 12/2/18
 */
public class RampEncoderDrive extends Command {

	private float distance; //inches
	private double stoppingDistance = 20; //inches
	private double speed; //out of 1
	private double filter; //out of 1, normally 0.1
	private double currentPower; //out of 1
	private Timer r_timer = new Timer();
	private double prevTime; //temp time data (seconds)
	private double prevDistance; //temp distance data (inches)
	private double loopTime = 0.05; //50ms
	private double loopDistance = 2; //inches
	private double powerThreshold = 0.05; //how close to something (out of 1)
	
	//WIP
	private Point2D[] table = {
			new Point2D.Double(0, 1),
			new Point2D.Double(0, 1),
			new Point2D.Double(0, 1),
			new Point2D.Double(0, 1),
			new Point2D.Double(0, 1),
			new Point2D.Double(0, 1)
	};
	
	//Constructor that defines filter
    public RampEncoderDrive(double _speed, float _distance, double _filter) {
    	requires(Robot.driveTrainSubsystem);
    	speed = _speed;
        distance = _distance;
        filter = _filter;
        setTimeout(15);
    }
    //Constructor that doesn't define filter
    public RampEncoderDrive(double _speed, float _distance) {
    	requires(Robot.driveTrainSubsystem);
    	speed = _speed;
        distance = _distance;
        filter = 0.1; //default filter
        setTimeout(15);
    }

    // Called just before this Command runs the first time
    protected void initialize() {
    	Robot.driveTrainSubsystem.setSpeed(0, 0);
    	Robot.driveTrainSubsystem.resetEncoders();
    	//added 11/18 setDistance
    	Robot.driveTrainSubsystem.setDistance();
    	r_timer.reset();
    	r_timer.start();
    	prevTime = 0;
    	prevDistance = 0;
    }

    // Called repeatedly when this Command is scheduled to run
    protected void execute() {
    	if (distance - Robot.driveTrainSubsystem.getAverageEncoderPosition() < stoppingDistance)
    	{
    		while (Robot.driveTrainSubsystem.getAverageEncoderPosition() - prevDistance < 2)
    		{
        		currentPower -= filter * currentPower;
            	Robot.driveTrainSubsystem.setSpeed(speed * currentPower, speed * currentPower);
    			prevDistance = Robot.driveTrainSubsystem.getAverageEncoderPosition();
    		}
    	} else
    	{
    		while ((r_timer.get() - prevTime > loopTime) && (currentPower < (1 - powerThreshold)))
        	{
        		currentPower += filter * (1 - currentPower);
            	Robot.driveTrainSubsystem.setSpeed(speed * currentPower, speed * currentPower);
            	prevTime = r_timer.get();
        	}
    	}
    	
    	Robot.driveTrainSubsystem.setSpeed(speed * currentPower, speed * currentPower);
    }

    // Make this return true when this Command no longer needs to run execute()
    protected boolean isFinished() {
        return (!(Robot.driveTrainSubsystem.getAverageEncoderPosition() < distance) ||  isTimedOut());
    }

    // Called once after isFinished returns true
    protected void end() {
    	Robot.driveTrainSubsystem.setSpeed(0, 0);
    }

    // Called when another command which requires one or more of the same
    // subsystems is scheduled to run
    protected void interrupted() {
    	end();
    }
}
