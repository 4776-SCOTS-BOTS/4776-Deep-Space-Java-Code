package org.usfirst.frc.team4776.robot.subsystems;

import org.usfirst.frc.team4776.robot.RobotMap;

import edu.wpi.first.wpilibj.*;
import edu.wpi.first.wpilibj.command.Subsystem;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;

/**
 *
 */
public class DriveTrainSubsystem extends Subsystem {

	DifferentialDrive driveTrain = RobotMap.DRIVE_TRAIN;
	Encoder leftEncoder = RobotMap.LEFT_ENCODER;
	Encoder rightEncoder = RobotMap.RIGHT_ENCODER;
	
	//added 11/18 encoder drive updates
		// Constants
		private static final double kDistancePerRevolution = 18.84;  // update
		private static final double kPulsesPerRevolution = 1024;     // update
		private static final double kDistancePerPulse = kPulsesPerRevolution / kDistancePerRevolution;
	
    public void initDefaultCommand() {
        // Set the default command for a subsystem here.
        //setDefaultCommand(new MySpecialCommand());
    }
    
    public void setSpeed (double left, double right)
    {
    	driveTrain.tankDrive(left, right);
    }
    public void resetEncoders ()
    {
    	leftEncoder.reset();
    	rightEncoder.reset();
    }
    //added 11/18
    public double getAverageEncoderPosition() {
        return ((double)leftEncoder.getRaw() + (double)rightEncoder.getRaw()) / (2 * kDistancePerPulse);
    }
    public double getAverageAbsEncoderPosition() {
        return ((double)Math.abs(leftEncoder.getRaw()) + (double)Math.abs(rightEncoder.getRaw())) / (2 * kDistancePerPulse);
    }
    
  //added 11/18
	public void setDistance() {
		leftEncoder.setDistancePerPulse(kDistancePerPulse);
	    rightEncoder.setDistancePerPulse(kDistancePerPulse);
	}
	
	
}

